/* 
Ejemplo de componente tipo clase que dispone de
los metodos de ciclo de vida
 */

