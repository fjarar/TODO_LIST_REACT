import React, { useState, useEffect } from "react";
import { getRandomUser } from "../services/axiosService";

const AxiosExample = () => {
  const [user, setUser] = useState(null);

  useEffect(() => {
    obtainRandomUser();
  }, []);

  const obtainRandomUser = () => {
    getRandomUser()
      .then((response) => {
        if (response.status === 200) {
          setUser(response.data.results[0]);
        }
      })
      .catch((error) => {
        alert(`Something went wrong: ${error}`);
      });
  };

  return (
    <div>
      <h1>Axios Example</h1>
      {user != null ? (
        <div>
          <img alt="avatar" src={user.picture.large}></img>
          <h2>
            {user.name.title} {user.name.first} {user.name.last}
          </h2>
          <h3>{user.email}</h3>
          <div>
            <p>Generate a new User</p>
            <button onClick={obtainRandomUser}>Random User</button>
          </div>
        </div>
      ) : (
        <div>
          <p>Please generate a new user</p>
        </div>
      )}
    </div>
  );
};

export default AxiosExample;
