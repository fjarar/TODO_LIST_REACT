import React from 'react';
import TaskListComponent from '../../components/container/task_list';

const TasksPage = () => {
    return (
        <div>
            <TaskListComponent></TaskListComponent>
        </div>
    );
}

export default TasksPage;
