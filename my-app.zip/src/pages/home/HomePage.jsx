import React from 'react';

const HomePage = () => {
    return (
        <div>
            <h1>Home Page</h1>
            <h2>Dashboard</h2>
        </div>
    );
}

export default HomePage;
